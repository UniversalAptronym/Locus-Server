window["Flexi"] =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/UI/Carouzelize.js":
/*!*******************************************************************************************!*\
  !*** /builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/UI/Carouzelize.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function() {\n\n    var Carouzelize = () => {\n        const CarouselComp = (elm) => {\n            var activeInd = 0;\n            const containerRef = elm.querySelector('.wdn-listv2-item-lists');\n            const totalItems = containerRef.querySelectorAll('.wdn-listv2-item').length;\n            const previousControl = elm.querySelector('.previous');\n            const nextControl = elm.querySelector('.next');\n            var offset;\n\n            const nextClicked = () => {\n                if (activeInd < (totalItems - offset)) {\n                    var nextInd = activeInd + offset;\n                    nextInd = nextInd > totalItems ? totalItems -1 : nextInd;\n                    containerRef.children[nextInd].scrollIntoView({\n                        behavior: \"smooth\",\n                        inline: \"start\",\n                        block: \"nearest\"\n                    });\n\n                    activeInd = nextInd;\n                }\n            }\n\n            const previousClicked = () => {\n                if (activeInd > 0) {\n                    var nextInd = activeInd - offset;\n                    nextInd = activeInd -offset < 0 ? 0 :nextInd;\n                    containerRef.children[nextInd].scrollIntoView({\n                        behavior: \"smooth\",\n                        inline: \"start\",\n                        block: \"nearest\"\n                    })\n                    activeInd = nextInd;\n                }\n            }\n\n            const checkControls = () => {\n                if (activeInd >= (totalItems - offset)) {\n                    nextControl.style.display = \"none\";\n                } else {\n                    nextControl.style.display = \"block\";\n                }\n                if (activeInd <= 0) {\n                    previousControl.style.display = \"none\";\n                } else {\n                    previousControl.style.display = \"block\";\n                }\n            }\n\n            const init = () => {\n                activeInd = 0;\n                offset = 0;\n                const containerWidth = containerRef.offsetWidth;\n                var offsetW = containerRef.offsetWidth;\n                containerRef.querySelectorAll('.wdn-listv2-item').forEach(\n                    (item) => {\n                        if (item.offsetLeft < offsetW) {\n                            offset++;\n                        }\n                    }\n                );\n                checkControls();\n            }\n\n            const reload = () => {\n                if(!isInViewport(containerRef)) {\n                    return;\n                }\n                activeInd = 0;\n                offset = 0;\n                containerRef.children[0].scrollIntoView({behavior: \"smooth\", inline: \"start\", block: \"nearest\"})\n                const containerWidth = containerRef.offsetWidth;\n                var offsetW = containerRef.offsetWidth;\n                containerRef.querySelectorAll('.wdn-listv2-item').forEach(\n                    (item) => {\n                        if (item.offsetLeft < offsetW) {\n                            offset++;\n                        }\n                    }\n                );\n                checkControls();\n            }\n\n            const isInViewport = (element) => {\n                const rect = element.getBoundingClientRect();\n                return (\n                    rect.top >= 0 &&\n                    rect.left >= 0 &&\n                    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&\n                    rect.right <= (window.innerWidth || document.documentElement.clientWidth)\n                );\n            }\n\n            init();\n            nextControl.addEventListener(\"click\", nextClicked);\n            previousControl.addEventListener(\"click\", previousClicked);\n            nextControl.addEventListener(\"click\", checkControls);\n            previousControl.addEventListener(\"click\", checkControls);\n            var timeId = null;\n            window.addEventListener('resize', () => {\n                clearTimeout(timeId);\n                timeId = setTimeout(reload, 500);\n            });\n\n        }\n\n        document.querySelectorAll('.flexi-carouzelize:not([data-flexi-carouzelize-on=\"true\"])').forEach((item) => {\n            if (window.getComputedStyle(item).display !== \"none\") {\n                item.setAttribute(\"data-flexi-carouzelize-on\", \"true\");\n                CarouselComp(item);\n            }\n        });\n\n    }\n    return Carouzelize;\n}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n\n//# sourceURL=webpack://Flexi//builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/UI/Carouzelize.js?");

/***/ }),

/***/ "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/Utils/Templating.js":
/*!*********************************************************************************************!*\
  !*** /builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/Utils/Templating.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_RESULT__;/* jslint evil: true, supernew:true */\n\n!(__WEBPACK_AMD_DEFINE_RESULT__ = (function() {\n\n    \"use strict\";\n\n    var Templating = new function () {\n        var cache = {};\n        this.init = function () {\n            this.cache = {};\n        };\n        /**\n         * Render the markup associated to a template and data\n         * @param {String} str id of the template or complete string to be transformed\n         * @param {Object} data The data object\n         * @returns HTML Markup\n         */\n        this.render = function (str, data) {\n            // Figure out if we're getting a template, or if we need to\n            // load the template - and be sure to cache the result.\n            var fn = !(/\\W/.test(str)) ?\n                cache[str] = cache[str] ||\n                this.render(document.getElementById(str) && document.getElementById(str).innerHTML) :\n\n                // Generate a reusable function that will serve as a template\n                // generator (and which will be cached).\n                new Function(\"obj\",\n                    \"var p=[],print=function(){p.push.apply(p,arguments);};\" +\n\n                        // Introduce the data as local variables using with(){}\n                    \"with(obj){p.push('\" +\n\n                        // Convert the template into pure JavaScript\n                    str\n                        .replace(/[\\r\\t\\n]/g, \" \")\n                        .split(\"<%\").join(\"\\t\")\n                        .replace(/((^|%>)[^\\t]*)'/g, \"$1\\r\")\n                        .replace(/\\t=(.*?)%>/g, \"',$1,'\")\n                        .split(\"\\t\").join(\"');\")\n                        .split(\"%>\").join(\"p.push('\")\n                        .split(\"\\r\").join(\"\\\\'\")\n                        .replace(/data-href/gm, 'href') +\n                    \"');}return p.join('');\");\n\n            // Provide some basic currying to the user\n            return data ? fn(data) : fn;\n        };\n    };\n\n    return Templating;\n}).call(exports, __webpack_require__, exports, module),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n\n//# sourceURL=webpack://Flexi//builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/Utils/Templating.js?");

/***/ }),

/***/ "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/Widgets/Filters.js":
/*!********************************************************************************************!*\
  !*** /builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/Widgets/Filters.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = (function () {\n    \"use strict\";\n\n    var Filters = function() {\n        this.filters = document.querySelectorAll('[name=\"widget-filter\"]');\n        this.targets = [].slice.call(this.filters).reduce(function(acc, current) {\n            var target = current.getAttribute('data-target');\n            var widget = document.querySelector('.' + target);\n            acc[target] = {\n                items: [].slice.call(widget.querySelectorAll('[data-title]'))\n            };\n            return acc;\n        }, {});\n        this.init();\n    };\n    \n    Filters.prototype = {\n        init: function() {\n            for (var i = 0; i < this.filters.length; i++) {\n                this.addEvent(this.filters[i]);\n            }\n        },\n        addEvent: function(filter) {\n            var self = this;\n            filter.addEventListener('keyup', function() {\n                self.filter(this.getAttribute('data-target'), this.value);\n            });\n        },\n        matchInput: function(value, item) {\n            return new RegExp(value, 'i').test(item.getAttribute('data-title'));\n        },\n        filter: function(target, value) {\n            if (!this.targets[target]) {\n                return;\n            }\n            var self = this;\n            var items = this.targets[target].items;\n            if (value) {\n                var hide = items.filter(function(item) {\n                    return !self.matchInput(value, item);\n                });\n                var show = items.filter(function(item) {\n                    return self.matchInput(value, item);\n                });\n                show.forEach(function(item) {\n                    item.classList.remove('hide');\n                });\n                hide.forEach(function(item) {\n                    item.classList.add('hide');\n                });\n            } else {\n                items.forEach(function(item) {\n                    item.classList.remove('hide');\n                });\n            }\n        }\n    };\n    \n    return Filters;\n}).call(exports, __webpack_require__, exports, module),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n\n//# sourceURL=webpack://Flexi//builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/Widgets/Filters.js?");

/***/ }),

/***/ "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/index.js":
/*!**********************************************************************************!*\
  !*** /builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/index.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [\n        __webpack_require__(/*! sortable */ \"../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/vendors/sortable.min.js\"),\n        __webpack_require__(/*! Flexi/Utils/Templating */ \"../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/Utils/Templating.js\"),\n        __webpack_require__(/*! Flexi/Widgets/Filters */ \"../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/Widgets/Filters.js\"),\n        __webpack_require__(/*! Flexi/UI/Carouzelize */ \"../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/UI/Carouzelize.js\"),\n    ], __WEBPACK_AMD_DEFINE_RESULT__ = (function ( sortable, Templating, Filters, Carouzelize) {\n        return {\n            'sortable': sortable,\n            'Templating': Templating,\n            'Filters': Filters,\n            'Carouzelize':Carouzelize\n        };\n    }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n\n\n\n//# sourceURL=webpack://Flexi//builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/index.js?");

/***/ }),

/***/ "../../../../src/FTE/FlexiBundle/Resources/public/js/Flexi/vendors/sortable.min.js":
/*!*************************************************************************************************!*\
  !*** /builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/vendors/sortable.min.js ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_RESULT__;(function() {\n    var a, b, c, d, e, f, g;\n    a = \"table[data-sortable]\", d = /^-?[£$¤]?[\\d,.]+%?$/, g = /^\\s+|\\s+$/g, c = [ \"click\" ], \n    f = \"ontouchstart\" in document.documentElement, f && c.push(\"touchstart\"), b = function(a, b, c) {\n        return null != a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent(\"on\" + b, c);\n    }, e = {\n        init: function(b) {\n            var c, d, f, g, h;\n            for (null == b && (b = {}), null == b.selector && (b.selector = a), d = document.querySelectorAll(b.selector), \n            h = [], f = 0, g = d.length; g > f; f++) c = d[f], h.push(e.initTable(c));\n            return h;\n        },\n        initTable: function(a) {\n            var b, c, d, f, g, h;\n            if (1 === (null != (h = a.tHead) ? h.rows.length : void 0) && \"true\" !== a.getAttribute(\"data-sortable-initialized\")) {\n                for (a.setAttribute(\"data-sortable-initialized\", \"true\"), d = a.querySelectorAll(\"th\"), \n                b = f = 0, g = d.length; g > f; b = ++f) c = d[b], \"false\" !== c.getAttribute(\"data-sortable\") && e.setupClickableTH(a, c, b);\n                return a;\n            }\n        },\n        setupClickableTH: function(a, d, f) {\n            var g, h, i, j, k, l;\n            for (i = e.getColumnType(a, f), h = function(b) {\n                var c, g, h, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D;\n                if (b.handled === !0) return !1;\n                for (b.handled = !0, m = \"true\" === this.getAttribute(\"data-sorted\"), n = this.getAttribute(\"data-sorted-direction\"), \n                h = m ? \"ascending\" === n ? \"descending\" : \"ascending\" : i.defaultSortDirection, \n                p = this.parentNode.querySelectorAll(\"th\"), s = 0, w = p.length; w > s; s++) d = p[s], \n                d.setAttribute(\"data-sorted\", \"false\"), d.removeAttribute(\"data-sorted-direction\");\n                if (this.setAttribute(\"data-sorted\", \"true\"), this.setAttribute(\"data-sorted-direction\", h), \n                o = a.tBodies[0], l = [], m) {\n                    for (D = o.rows, v = 0, z = D.length; z > v; v++) g = D[v], l.push(g);\n                    for (l.reverse(), B = 0, A = l.length; A > B; B++) k = l[B], o.appendChild(k);\n                } else {\n                    for (r = null != i.compare ? i.compare : function(a, b) {\n                        return b - a;\n                    }, c = function(a, b) {\n                        return a[0] === b[0] ? a[2] - b[2] : i.reverse ? r(b[0], a[0]) : r(a[0], b[0]);\n                    }, C = o.rows, j = t = 0, x = C.length; x > t; j = ++t) k = C[j], q = e.getNodeValue(k.cells[f]), \n                    null != i.comparator && (q = i.comparator(q)), l.push([ q, k, j ]);\n                    for (l.sort(c), u = 0, y = l.length; y > u; u++) k = l[u], o.appendChild(k[1]);\n                }\n                return \"function\" == typeof window.CustomEvent && \"function\" == typeof a.dispatchEvent ? a.dispatchEvent(new CustomEvent(\"Sortable.sorted\", {\n                    bubbles: !0\n                })) : void 0;\n            }, l = [], j = 0, k = c.length; k > j; j++) g = c[j], l.push(b(d, g, h));\n            return l;\n        },\n        getColumnType: function(a, b) {\n            var c, d, f, g, h, i, j, k, l, m, n;\n            if (d = null != (l = a.querySelectorAll(\"th\")[b]) ? l.getAttribute(\"data-sortable-type\") : void 0, \n            null != d) return e.typesObject[d];\n            for (m = a.tBodies[0].rows, h = 0, j = m.length; j > h; h++) for (c = m[h], f = e.getNodeValue(c.cells[b]), \n            n = e.types, i = 0, k = n.length; k > i; i++) if (g = n[i], g.match(f)) return g;\n            return e.typesObject.alpha;\n        },\n        getNodeValue: function(a) {\n            var b;\n            return a ? (b = a.getAttribute(\"data-value\"), null !== b ? b : \"undefined\" != typeof a.innerText ? a.innerText.replace(g, \"\") : a.textContent.replace(g, \"\")) : \"\";\n        },\n        setupTypes: function(a) {\n            var b, c, d, f;\n            for (e.types = a, e.typesObject = {}, f = [], c = 0, d = a.length; d > c; c++) b = a[c], \n            f.push(e.typesObject[b.name] = b);\n            return f;\n        }\n    }, e.setupTypes([ {\n        name: \"numeric\",\n        defaultSortDirection: \"descending\",\n        match: function(a) {\n            return a.match(d);\n        },\n        comparator: function(a) {\n            return parseFloat(a.replace(/[^0-9.-]/g, \"\"), 10) || 0;\n        }\n    }, {\n        name: \"date\",\n        defaultSortDirection: \"ascending\",\n        reverse: !0,\n        match: function(a) {\n            return !isNaN(Date.parse(a));\n        },\n        comparator: function(a) {\n            return Date.parse(a) || 0;\n        }\n    }, {\n        name: \"alpha\",\n        defaultSortDirection: \"ascending\",\n        match: function() {\n            return !0;\n        },\n        compare: function(a, b) {\n            return a.localeCompare(b);\n        }\n    } ]), setTimeout(e.init, 0),  true ? !(__WEBPACK_AMD_DEFINE_RESULT__ = (function() {\n        return e;\n    }).call(exports, __webpack_require__, exports, module),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : undefined;\n}).call(this);\n\n//# sourceURL=webpack://Flexi//builds/vanilla/fte/src/FTE/FlexiBundle/Resources/public/js/Flexi/vendors/sortable.min.js?");

/***/ })

/******/ });